public class Samochod extends Pojazd {
    public Samochod(String marka, String model) {
        super(marka, model);
    }
}
