public class Main {
    // Zad dom zrobić to samo tyle zwierze
    // makeSound(), rasa(), imie(), useMakeNoise(list<> zwierzaków)
    // displayName(list<> zwierzaków) -> foreach(zwierzaka: list<>) { sou() }

    public static void main(String[] args) {
        //System.out.println("Hello world!");

        String name2 = "Piotr";

        String name3 = new String(name2);

        String name4 = name2;

        System.out.println(name3 == name2);
        System.out.println(name4 == name2);


        Auto auto1 = new Auto();
        ObiektA obiekt = new ObiektA();

        auto1.setMarka("Opel");
        auto1.setKolor("Czerwony");
        auto1.setModel("Corsa");

        System.out.println(auto1.toString());

        auto1.wypiszAuto();

        obiekt.sayHelloWorld();
        obiekt.returnRandomNumber();

        Samochod samochod1 = new Samochod("Honda", "Civic");
        Samolot samolot1 = new Samolot("Ford", "Focus");
        Jacht jacht1 = new Jacht("Porsche", "911");
        useMakeNoise(samochod1);
        useMakeNoise(samolot1);
        useMakeNoise(jacht1);

        public static void useMakeNoise(Pojazd pojazd) {
            pojazd.makeNoise();
        }
    }
}