public interface Interface {
    void sayHelloWorld();

    Double returnRandomNumber();
}
