public class ObiektA implements Interface {

    private String a;

    private String nazwisko;


    @Override
    public void sayHelloWorld() {
        System.out.println("Hello world!");
    }

    @Override
    public Double returnRandomNumber() {
        return Math.random();
    }
}
