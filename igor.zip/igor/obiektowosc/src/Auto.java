public class Auto extends Pojazd {
    public Auto(String marka, String model) {
        super(marka, model);
    }

    public Auto() {
        super();
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public void setKolor(String kolor) {
        this.kolor = kolor;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getMarka() {
        return marka;
    }

    public String getKolor() {
        return kolor;
    }

    public String getModel() {
        return model;
    }

    private String kolor;
    private String marka;
    private String model;

    @Override
    public String toString() {
        return "Auto{" +
                "kolor='" + kolor + '\'' +
                ", marka='" + marka + '\'' +
                ", model='" + model + '\'' +
                '}';
    }

    public void wypiszAuto(){
        System.out.println("Twoje auto to: " + marka + "\nModel: " + model + "\nKolor: " + kolor);
    }
}
